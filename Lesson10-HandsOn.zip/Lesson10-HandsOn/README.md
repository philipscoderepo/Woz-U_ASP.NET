# ASP.NET Core logging sample application

This sample application is for the [ASP.NET Core Logging](https://docs.microsoft.com/aspnet/core/fundamentals/logging/index) article and is based on the sample created for the [First Web API with ASP.NET Core MVC](https://docs.microsoft.com/aspnet/core/tutorials/first-web-api) tutorial.
